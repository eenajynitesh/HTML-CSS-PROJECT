<!DOCTYPE html>
<html>
<head>
<style>


a:link {
    color: green;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: pink;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: red;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: yellow;
    background-color: transparent;
    text-decoration: underline;
}




h1 {
    color: blue;
    font-family: verdana;
    font-size: 300%;

}
p  {
    color: red;
    font-family: courier;
    font-size: 160%;margin-right:70px;
}
body {
   background-image: url("back.jpg");
 background-image:no-repeat;
background-size:100% 100%;
padding: 10px;
 background-attachment: fixed;
}
p1
{

 color:red;
 font-size:300%;
}

</style>
</head>
<body>
<h1 style="text-align:center;color:white;background-color:rgb(0,128,128);">TOP 5 TELEVISIONS</h1>
<table>
<p style="color:white;font-size:160%"><b>TV technology has not really seen big changes recently, but things took a new turn in 2016. The incorporation of HDR video into televisions, adds true value addition to TVs, something that 4K or 3D never could bring. HDR video actually brings a noticeable changes to picture quality, and though its availability is limited right now, and TVs supporting HDR are expensive, we can�t wait for this tech to trickle down. Our favourites are based on TVs we reviewed so far.

</b></p>
<p style="color:red;font-size:140%"><b><a href="lg/lgtv.html" target="_blank">1.LG Ultra HD (4K) OLED Smart TV</a></b></p> 
<tr>
<td><img src="l1.jpg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The LG C8 bring with it fantastic picture quality, a smooth OS and a sleek design. The audio is underwhelming for the price and all of LGs smart features aren�t available in India for the TV. But if picture quality is a priority, you can�t go wrong with the LG C8.</br></blockquote>








<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
LG
<br>Product Name:
LG Ultra HD (4K) OLED Smart TV (OLED55C8PTA) 55-inch
<br>Price (MRP):
224000
<br>screen size (in inches):
55
<br>Screen type:
4K OLED
<br>TV Type:
4K OLED Smart TV</br></blockquote></td>
</tr></table>
  

<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=7&cad=rja&uact=8&ved=2ahUKEwism4aBiNrcAhUKSY8KHdd5CBYQFjAGegQIBRAB&url=https%3A%2F%2Fwww.amazon.com%2FLG-Electronics-OLED55B6P-55-Inch-Ultra%2Fdp%2FB01CDF9S1G&usg=AOvVaw1tcxPy4Uk6JFV82ZZaosSk">LG Ultra HD (4K) OLED Smart TV</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="samsung1/samsung1.html" target="_blank">2.Samsung QLED Q8C</a></b></p>
<td><img src="sams1.jpeg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The LG C8 bring with it fantastic picture quality, a smooth OS and a sleek design. The audio is underwhelming for the price and all of LGs smart features aren�t available in India for the TV. But if picture quality is a priority, you can�t go wrong with the LG C8.</br></blockquote>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
">


<b>GENERAL INFORMATION</b><br>
Brand:
SAMSUNG
<br>Product Name:
Samsung QLED Q8C
<br>Price (MRP):
235100
<br>screen size (in inches):
55
<br>Screen type:
 QLED
<br>TV Type:
 QLED Smart TV</br></blockquote></td>
</tr></table>


<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=4&cad=rja&uact=8&ved=2ahUKEwjcobX3iNrcAhWHNI8KHfYiCY0QFjADegQIBxAB&url=https%3A%2F%2Fwww.amazon.in%2FSamsung-inches-QA55Q8C-Curved-Smart%2Fdp%2FB06ZYY5361&usg=AOvVaw0AbXqwzt7GTcV7paU7L14Y">Samsung QLED Q8C</a></q></p>




<table>
<p style="color:red;font-size:140%"><b><a href="samsung2/samsung2.html" target="_blank">
3.SAMSUNG 55KS9000 SUHD</a>
</b></p> 
<tr>
<td><img src="sam1.jpeg"width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></b></q></em></p>


<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Samsung 55KD9000 is a 55-inch Smart television, which is part of Samsung's 2016 SUHD range. It costs Rs. 2,59,900 and boasts Samsung's Quantum Dot technology. It runs on the Tizen operating system.</br></blockquote>




<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;">
<b>GENERAL INFORMATION</b><br>
Brand:
SAMSUNG
<br>Product Name:
Samsung 55KS9000 SUHD
<br>Price (MRP):
321100
<br>screen size (in inches):
55
<br>Screen type:
SUHD
<br>TV Type:
4K OLED Smart TV</br></blockquote></td>
</tr></table>


<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=5&cad=rja&uact=8&ved=2ahUKEwj86sOXidrcAhVKqI8KHVoCDT8QFjAEegQIBhAB&url=https%3A%2F%2Fwww.amazon.com%2FSamsung-UN55KS9000-55-Inch-Ultra-Smart%2Fdp%2FB01C5TFNOG&usg=AOvVaw0k_TRMAn3WwSv1gJG_5Q0T">Samsung 55KS9000 SUHD</a></q></p>



<table>
<p style="color:red;font-size:140%"><b><a href="sony/sony.html" target="_blank">4.Sony Bravia Z9D 4K HDR TV</a>
</b></p> 
<tr>
<td><img src="s2.jpeg"width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></b></q></em></p>


<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
Sony Bravia Z9D 4K HDR TV is a high end Smart TV that comes with a 65 inch 4K Ultra HD Smart LED screen that supports 3840 x 2160 pixels resolution and  Backlight Master Drive technology that has a new optical LED design which keeps light only where it's needed in each scene. It is powered by 4K HDR Processor X1 Extreme that optimises and enhances colour and contrast and upscales content from any source nearer to 4K HDR quality. </br></blockquote>




<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;">
<b>GENERAL INFORMATION</b><br>
Brand:
Sony
<br>Product Name:
Sony Bravia Z9D 4K HDR with Android TV
<br>Price (MRP):
504900
<br>screen size (in inches):
65
<br>Screen type:
4K Ultra LED
<br>TV Type:
Smart TV</br></blockquote></td>
</tr></table>


<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=8&cad=rja&uact=8&ved=2ahUKEwiP9_jBidrcAhWDs48KHYVSDEcQFjAHegQIChAB&url=https%3A%2F%2Fwww.amazon.com%2FSony-XBR65Z9D-65-Inch-Ultra-Smart%2Fdp%2FB01HY6W3Z2&usg=AOvVaw1d27TmfeGfxvDZwydZ9mG_">Sony Bravia Z9D 4K HDR</a></q></p>


<table>
<p style="color:red;font-size:140%"><b><a href="xiaomi/xiaomi.html" target="_blank">5.Xiaomi Mi TV 4
</a>
</b></p> 
<tr>
<td><img src="x3.jpeg"width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></b></q></em></p>

<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
Xiaomi has launched the Mi LED Smart TV 4 in India. The smart TV has a 138.8cm/ 55 inch display and is being touted as the world�s thinnest LED TV. At just 4.9 mm thin, Mi TV seamlessly blends in your surroundings. The TV is claimed to be 30 percent thinner than the iPhone 7. It fits into your wall like a picture frame. It has a big screen with a grand display. The TV has a big screen and a grand display for the ultimate viewing experience.</br></blockquote>




<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;">
<b>GENERAL INFORMATION</b><br>
Brand:
Xiaomi
<br>Product Name:
Mi TV 4
<br>Price (MRP):
39999
<br>screen size (in inches):
55
<br>Screen type:
4K UHD
<br>TV Type:
Smart TV</br></blockquote></td>
</tr></table>


<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Flipkart:-</em><q><a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjmv673idrcAhUR448KHRNfBb8QFjAAegQIChAB&url=https%3A%2F%2Fwww.flipkart.com%2Fmi-led-4k-smart-tv4-55inch-store&usg=AOvVaw1uhC3tRx7YuG7LNL-M9ScA">Mi TV 4</a></q></p>


<p style="text-align:center;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;"><b><a href="menu.php">BACK</a></b></p>


</body>
</html>

