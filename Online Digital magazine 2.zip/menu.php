<html>
    <head>
        <title>MENU</title>
        <link href="cssmenu.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div class="row">
              
            <ul class="navbar">
                <li><a href="index.php">HOME</a></li>
                <li class="active"><a href="menu.php">MENU</a></li>
                <li><a href="gallery.php">GALLERY</a></li>
                <li><a href="subscribe.php">SUBSCRIBE</a>
                </li>    
            </ul>
           <div class="logo">
	<img src="logo2.png">
	</div>
            <div class="menu">
                <h1>MENU:</h1>
            </div>
        </div>
         
        <div class="content">
        <div class="content1">
            <div class="button1">
                <a href="phones.php"> 1.MOBILES </a>
            </div>
            <div class="img1">
                <img  src="phone/asus2.jpg">
            </div>
            
            <div class="text1">
                <p>Here we have the list of  top 5 smart phones and their detailed reviews</p>
            </div>
        </div>
        <div class="content2">
            <div class="button2">
                <a href="laptops.php"> 2.LAPTOPS </a>
            </div>
            <div class="img2">
                <img src="lap/vivo1.jpg">
                
            </div>
            
            <div class="text2">
                <p>Here we have the list of  top 5 Laptops and their detailed reviews</p>
            </div>
        </div>
        <div class="content3">
            <div class="button3">
                <a href="tv.php"> 3.SMART TV </a>
            </div>
            <div class="img3">
                <img src="sam1.jpeg">
                
            </div>
            
            <div class="text3">
                <p>Here we have the list of  top 5 Smart TV's and their detailed reviews</p>
            </div>
        </div>
         <div class="content4">
            <div class="button4">
                <a href="smartwatches.php"> 4.WATCHES </a>
            </div>
            <div class="img4">
                <img src="watch/moto1.jpg">
                
                
            </div>
            
            <div class="text4">
                <p>Here we have the list of  top 5 smart watches and their detailed reviews</p>
            </div>
        </div>

        <div class="content5">
            <div class="button5">
                <a href="gadgets.php"> 5.GADGETS </a>
            </div>
            <div class="img5">
                <img src="gad/aw3.jpg">
                
            </div>
            
            <div class="text5">
                <p>Here we have the list of  top 10 Gadgets and their detailed reviews</p>
            </div>
        </div>
        </div>
    </body>
</html>
