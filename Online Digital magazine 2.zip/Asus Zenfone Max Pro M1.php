<html>
<head>
<style>
#block1
{
    float:left;
   background:linear-gradient(to bottom right,rgb(252,213,110), rgb(222,197,236));
    margin: 10px 20px;
    padding: 20px;
    width: 180px;
}


#block2
{
    float:right;
    background:linear-gradient(to bottom right,rgb(252,213,110), rgb(222,197,236));
    margin: 10px 20px;
    padding: 20px;
    width: 180px;
}


#block3
{
    float:left;
    background:linear-gradient(to bottom right,rgb(252,213,110), rgb(222,197,236));
    margin: 10px 20px;
    padding: 20px;
    width: 180px;
}
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 800px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}




</style>

<head>
<link rel="stylesheet" href="style.css">

</head>


<h1>ASUS ZENFONE MAX PRO M1</h1>
<title>Asus Zenfone Max Pro M1(4GB)</title>
<h2>Our Verdict</h2>
<p> The Asus Zenfone Max Pro can take on the best in the market with ease. Like most Asus phones, the spec-sheet is maxed out with the best mid-range hardware. That includes latest stock Android and a 5,000mAh battery, two features which solve the biggest pain points people tend to have when making a purchase at that price range. The phone even manages to take on the formidable Redmi Note 5 Pro, save for the imaging prowess, but the pros easily outweigh the cons. In all, it's always good to have a choice of clean stock UI without compromising on the performance.
</p><br>


<div id="block1">
<h2>PROS</h2>
<ul>
<li>Latest stock Android 8.1 Oreo out of the box
<li>Two-day long battery
<li>The latest mid-range chipset, tall 18:9 display
<li> Massive 5,000mAh battery
</ul>
</div>

<div id="block2">
<h2>CONS</h2>
<ul>
<li>Shoddy camera
<li>Generic design
<li>Plastic borders 
<li>Unstable
</ul>
</div>

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="pics/asus1.jpg" width="790" height="500">
  <div class="text">Design</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="pics/asus2.jpg" width="790" height="500">
  <div class="text">18:9 Aspect ratio</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="pics/asus3.jpg" width="790" height="500">
  <div class="text">13+5 MP rear camera</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

<h1>Asus Zenfone Max Pro M1 64GB: Detailed Review:</h1>
<p>The mid-range market is now dominated by Xiaomi. There's one Redmi phone for every price point in that segment and the consumer is essentially spoilt for choice. However, Redmi phones are notorious for getting sold out in seconds. Getting your hands on one is a matter of pure luck. But then again, we have always recommended our readers to wait and try their luck because no other phonemaker has been able to match up to the quality Xiaomi assures in its products. That is, until now.

The Asus Zenfone Max Pro is a breath of fresh air in a market that is otherwise inundated with Xiaomi phones. Asus offering matches Xiaomi's most premium mid-range offering feature-by-feature and for the most part, can be considered an equal. Except, the Max Pro runs on stock Android UI while the Redmi Note 5 Pro is of course powered by MIUI. There's nothing wrong with using MIUI, but there's a certain simplicity and comfort in using stock Android. It's familiar to anyone who has used an Android device and is efficient enough to not tax the processor. Considering how the UI is the most frequent aspect of the phone a user will interact with, it counts a lot, and in this case, Asus choice makes the Zenfone Max Pro a force to reckon with. What's better is that the phone is much cheaper than the Redmi Note 5 Pro and will be available more easily than the Redmi Note 5 Pro.
The question then remains, did Asus finally crack the formula to make a reliable mid-range phone? With the Zenfone Max Pro, it certainly seems so. It has everything you can ask for at the price. The latest mid-range chipset, tall 18:9 display, dual cameras and a massive 5,000mAh battery. In this review, we find out whether all the features work as advertised, and more importantly, does it make sense to buy this over the Redmi Note 5 Pro? Read on.
</p><br>
<body>
<iframe width=100% height="400" 
src="https://www.youtube.com/embed/9xo3jR4NP6w">autoplay=1">
</iframe>
<br>
</body>



<div id="block3">
<h2>Key Specifications</h2>
<ul>
<li>storage:64GB
<li>removable storage (yes or no):Yes
<li>cpu:Qualcomm SDM636 Snapdragon 636
<li>CPU speed:1.8 GHz
<li>processor cores:Octa
<li>RAM:6GB
<li>gpu:Adreno 509
</ul>
</div>


<br><h2>Build and Design: New Design, same approach:</h2>
<p>
Taller displays aren't new anymore and neither is the metal unibody design most mid-range smartphones like to sport. The Zenfone Max Pro is yet another iteration of the same design philosophy. The display takes up most of the real estate up front while at the back the dual camera module is vertically aligned at the top left corner. The fingerprint sensor is conveniently placed in the center where the finger can easily reach it. The form factor with a thinner display is naturally ergonomic and the rounded corners makes the phone sit plush in the hand.<br>
Like most other mid-range phones, the Zenfone Max Pro also deploys a 2.5D curved glass that bends ever so slightly to meet the metal frame. Asus has polished the rear plate to give a soft matte finish that does tend to get dirty when used with sweaty hands but isn't a fingerprint magnet. There are two colour variants to choose from Meteor Silver and Deepsea Black. Both look equally good and you'll be hard pressed to make a choice. There's colour-matched polycarbonate antenna lines to enhance network reception.
I particularly liked the fact that the dual camera module is flush with the body and there's no camera bump, which has become an eyesore in most smartphones. There's also no need to make a choice between a second SIM card and a microSD card as the phone houses dedicated slots for all three. In the mid-range market, that counts as a lot since most users tend to use a secondary SIM card and rely on expanded storage.
The design of the Zenfone Max Pro isn't going to get points for being innovative, but it does comes across as well-built and functional. The added heft, thanks to the massive 5,000mAh battery provides a good grip and the minimalist body makes the display the center of attraction.
</p><br>

<h2> Battery life: Still runs for two days straight:</h2>
<p >
One of the highlights of the Zenfone Max Pro is the 5,000mAh battery. Asus has managed to maintain a slim profile despite maxing out the battery capacity. It does help and combined with the power-efficient chipset and stock Android UI, the 5,000mAh battery can easily last the phone over a day and a half. PCMark's 2.0 Battery test ran for 10 hours 39 minutes which easily converts to over a day of use. One of the main reason to recommend the phone is for the long battery life. Asus also bundles a fast charger with the device that can charge the phone to its full capacity in around 2 hours 30 minutes.
  </p><br>

<h2>Camera: The new best</h2>
<p>While the Zenfone Max Pro matches the competition in every other aspect, the camera leaves a lot to be desired. It's not a bad camera per se, but photos from phones like the Redmi Note 5 Pro has spoilt me. The Zenfone Max Pro features dual cameras at the back A 13-megapixel primary sensor and a 5-megapixel depth-sensing unit. The camera is placed at the top left corner with a single LED flash right beneath it. The primary camera has an aperture of f/2.2 with 1.0um pixel pitch.
The camera specs are mostly the same as the Redmi Note 5 Pro, which is our best-ranking mid-range phone currently, but the results are not the same. Photos from the Zenfone Max Pro are average, to say the least. That wow factor is missing. Highlights get clipped often and details in the textures isn't as prominent as the best in the market. It's still better than most other mid-rangers, but if you're looking for the absolute best, it's best to try your luck in getting the Note 5 Pro.
The camera UI on the Zenfone Max Pro is somewhat cluttery and isn't quite aesthetically pleasing as in other phones by Moto or Xiaomi. Asus deployed Qualcomm's stock camera app which does offer a range of scenes to choose, as well as filters, but most options like the pro-mode are cluttered inside the settings page, making it a hassle to adjust the settings manually.</p><br>
<ul>
<li>
<h3>Daylight</h4>
<br><p>Any mid-range phones will take decent daytime shots with ample light pouring into the frame. So does the Zenfone Max Pro. You will get well-lit photos which are bright and vibrant. The colour temperature does tend towards the warmer side, but they look aesthetically pleasing regardless. But as I mentioned above, the camera isn't a match for the Redmi Note 5 Pro. Highlights tend to get overexposed when exposing for the shadows and details are lost in the shadows when trying to prioritise highlights. The dynamic range leaves a lot to be desired.</p><br>
<li>
<h3>Indoor</h4>
<p>The photos taken indoors highlight the weaknesses of the camera. There's an ugly glare from the incandescent source of light when taking photos indoors, while close-up shots are somewhat well-lit but aren't as sharp. The white balance is more accurate though, as compared to the Redmi Note 5 Pro, which is definitely a good thing.</p><br>
<li>
<h3>Macro</h4>
<p>
Close-up shots, taken in daylight will result in well-detailed, sharp macro shots. In the photo below, the details in the flower are well-preserved while the colour of the flower came out a little more saturated, yet not as much as the Redmi Note 5 Pro.</p><br>
<li>
<h3>Low-light</h4>
<p>The camera on the Zenfone Max Pro isn't conducive for use in low-light. There's considerable noise in the photos. The shadows are practically blackened and whatever area is lit is mired in grains. To be frank though, most mid-rangers aren't capable of good low-light shots and this one is just the same.</p><br>
<li>
<h4>Portrait Shots</h4>
<p>Bokeh shots are ever so popular now and phones like the Redmi Note 5 Pro and the Mi A1 are known to be masters at it. The Zenfone Max Pro tries hard to match up to that level, but doesn't quite make it. There's ample blurring, yes, but the blurring is inconsistent and the portrait comes across as being heavily edited on Snapseed. You also cannot control the amount of blurring, something that Honor phones do provide.</p><br>
<li>
<h4>Front Camera</h4>
<p>
The Zenfone Max Pro sports an 8-megapixel shooter with F/2.0 aperture combined with a soft LED flash. The selfies actually come out well-detailed with the right amount exposure and minimal beauty effects. It can also take portrait selfies and unlike other selfie-centric phones like the Oppo F7, the background isn't overexposed to make the portrait stand out. The Max Pro manages to do it without clipping the background light.
</p><br>
</li>
</ul>
<h2>Bottomline</h2>
<p>The Asus Zenfone Max Pro may stands particularly because of the superior performance and the choice of stock Android at that price. There are other stock Android phones available at this price as well, but none of them pack so much firepower inside as the Zenfone Max Pro. It performs neck-to-neck with the Redmi Note 5 Pro, but Xiaomi's offering far better in the camera department. But if you are a stickler for a hassle-free UI, superior performance and long battery life, this is the phone to go for. The fact that it's also cheaper than the Redmi Note 5 Pro makes it a no-brainer. Also, unlike the Note 5 Pro, this one won't be sold through flash sales, so availability is not going to be an issue. Combine that with Flipkart's Complete Mobile Protection for Rs 49, and Asus has a winner in its hands. If only the name was a little easier to say.<br>
</p>
</body>
</html>

