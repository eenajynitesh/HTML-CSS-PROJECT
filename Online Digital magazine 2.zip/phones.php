
<html>
<head>
<style>

a:link {
    color: red;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: pink;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: green;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: yellow;
    background-color: transparent;
    text-decoration: underline;
}

h1 {
    color: blue;
    font-family: verdana;
    font-size: 300%;

}
p  {
    color: red;
    font-family: courier;
    font-size: 160%;margin-right:70px;
}
body {
   background-image: url("smart.jpg");
   background-size:100%;
padding: 10px;
 background-attachment: fixed;	
 background-image:no-repeat;
}
p1
{

 color:red;
 font-size:300%;
}

</style>
</head>
<body>
<h1 style="text-align:center;color:white;background-color:rgb(0,128,128);">TOP 5 SMART PHONES</h1>
<table>
<p style="color:white;font-size:100%"><b>As technology moves forward and smartphones are become more powerful, their ability to do more has increased. In recent times, latest smartphones are featuring almost 8GB of DDR4 RAM which more than the RAM available on a normal laptop. While you may be using a 1080p Television at home, the screen resolution on the top tier smartphones have moved onto 4K. Not just that, the camera quality is coming nearer to DSLRs with each new smartphone. However, all these phone do come at premium price. So, here are the best mobiles phones you can buy in India. Our list of the best phones 2018 to buy in India, offers the right mix of performance and features. Click on each of the recommended top 5 smartphone to read detailed reviews and get more information on the best smartphones in India.</b></p>
<p style="color:red;font-size:140%"><b><a href="Asus Zenfone Max Pro M1.php" target="_blank">1.ASUS ZENFONE MAX PRO M1(64GB)</a> </b></p> 

<tr>
<td><img src="pics/asus1.jpg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Asus Zenfone Max Pro can take on the best in the market with ease. Like most Asus phones, the spec-sheet is maxed out with the best mid-range hardware. That includes latest stock Android and a 5,000mAh battery, two features which solve the biggest pain points people tend to have when making a purchase at that price range. The phone even manages to take on the formidable Redmi Note 5 Pro, save for the imaging prowess, but the pros easily outweigh the cons. In all, it�s always good to have a choice of clean stock UI without compromising on the performance.</br></blockquote>

<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
ASUS
<br>Product Name:
ASUS ZENFONE MAX PRO M1
<br>Price (MRP):
12,999
<br>screen size (in inches):
6 inch
<br>Screen type:
18:9 FULL HD+
<br>RAM:4gb
</tr></table>
  

<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Flipkart:-</em><q><a href="https://www.flipkart.com/asus-zenfone-max-pro-m1-grey-64-gb/p/itmf4hg4bhbbng96">BUY NOW</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="Xiaomi redmi note 5 pro.php" target="_blank">2.Xiaomi redmi note 5 pro(64GB)</a></b></p>
<td><img src="pics/xiaomi1.jpeg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Xiaomi Redmi Note 5 Pro is currently the best smartphone you can buy in the sub 15K segment. It offers excellent performance, has a two-day battery life, both front and rear cameras are good and it has a sturdy build quality.
</br></blockquote>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Xiaomi
<br>Product Name:
Xiaomi Redmi Note 5 Pro(4GB)
<br>Price (MRP):
14,999
<br>screen size (in inches):
6 inch
<br>Screen type:
18:9 FULL HD+
<br>RAM:4GB
</tr></table>


<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Flipkart:-</em><q><a href="https://www.flipkart.com/redmi-note-5-pro-black-64-gb/p/itmf2fc3xgmxnhpx?pid=MOBF28FTQPHUPX83&srno=s_1_1&otracker=search&lid=LSTMOBF28FTQPHUPX83BUJJ2C&fm=SEARCH&iid=d3468043-4d78-47f6-8aa1-d0d0c6c244f7.MOBF28FTQPHUPX83.SEARCH&ppt=Product%20Page&ppn=Product%20Page&ssid=85g5eb17wg0000001533552939133&qH=286b43aac83aafdc">BUY NOW</a></q></p>










<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="realme1.php" target="_blank">3.OPPO REALME 1 128GB(64GB)</a> </b></p> 

<tr>
<td><img src="pics/realme2.jpeg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The good looks of the Realme 1 hides the inconsistencies of the phone. It tries to get ahead of the game by gaming the synthetic benchmarks but falls flat in real world performance. It positions itself as a selfie-centric phone but the selfies from the phone comes off as artificial and puffed up.</br></blockquote>

<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
">
<b>GENERAL INFORMATION</b><br>
Brand:
ASUS
<br>Product Name:
OPPO REALME 1 128GB
<br>Price (MRP):
10,999
<br>screen size (in inches):
6 inch
<br>Screen type:
18:9 FULL HD+
<br>RAM:6gb</br></blockquote></td>
</tr></table>
  

<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.amazon.in/RealMe-Diamond-Black-128-GB/dp/B078BNQ313">BUY NOW</a></q></p>

<table>
<tr>




<p style="color:red;font-size:140%"><b><a href="C:/Users/EENJAY/Desktop/final/phones/honor%209n.html" target="_blank">4.Huawei Honor 9N</a> </b></p> 

<tr>
<td><img src="pics/h9n1.jpeg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Honor 9N is a well-built device for its price range and offers good colour options in the sub-15K price bracket. However, it uses a dated Kirin 659 chipset and does not offer fast charging. The camera can deliver nice photos in good lighting conditons, but falters badly in low light. Overall, the Honor 9N fails to stand out from the competition when it comes to overall performance. If good overall performance is what you are looking for, then you can't go wrong with the Xiaomi Redmi Note 5 Pro in this price segment.</br></blockquote>







<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
HUAWEI
<br>Product Name:
Honor 9N
<br>Price (MRP):
13,999
<br>screen size (in inches):
6 inch
<br>Screen type:
18:9 FULL HD+
<br>RAM:4gb
</tr></table>
  

<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/mobile-phones/huawei-honor-9n-review-134316.html#popup1">BUY NOW</a></q></p>

<table>
<tr>

<p style="color:red;font-size:140%"><b><a href="honor nova.php" target="_blank">5.HONOR NOVA 3</a> </b></p> 

<tr>
<td><img src="pics/hn33.jpeg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Huawei Nova 3 packs all the features that are in demand this year. It particularly excels in the design. The dual tone glass back looks simply stunning. But the good looks inside is marred by an ugly EMUI interface. The performance of the phone also isn�t at par with the competition, and the AI features are a hit or miss. The camera on the Nova 3 is good, but quite inconsistent. Overall, this is a device that will work best under ideal conditions, but a little out of the comfort zone, and the shortfalls start showing.</br></blockquote>







<blockquote  style="color:white;font-size:120%;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
HUAWEI
<br>Product Name:
Honor 9N
<br>Price (MRP):
18,999
<br>screen size (in inches):
6 inch
<br>Screen type:
18:9 FULL HD+ with Notch
<br>RAM:6gb
</tr></table>
  

<p style="color:Orange;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://consumer.huawei.com/ae-en/campaign/nova-3e-pre-order/">BUY NOW</a></q></p>

<table>
<tr>




<p style="text-align:center;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;"><b><a href="menu.php">BACK</a></b></p>


</body>
</html>

