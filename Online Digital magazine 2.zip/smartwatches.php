
<html>
<head>
<style>

a:link {
    color: red;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: pink;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: green;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: yellow;
    background-color: transparent;
    text-decoration: underline;
}

h1 {
    color: blue;
    font-family: verdana;
    font-size: 300%;

}
p  {
    color: red;
    font-family: courier;
    font-size: 160%;margin-right:70px;
}
body {
   background-image: url("pics/background.jpg");
 background-image:no-repeat;
 background-size: 100% 100%;
background-attachment: fixed;
}
p1
{

 color:red;
 font-size:300%;
}

</style>
</head>
<body>
<h1 style="text-align:center;color:White;background-color:rgb(0,128,128);">TOP 5 SMARTWATCHES</h1>
<table>
<p style="color:black;font-size:100%"><b>A Smartwatch is a device, which can make your constant notification filled life much simpler. Besides functionality, a smartwatch should also look good on your hand. There are plenty of good smartwatches in the market and some really bad ones as well, but which smartwatch you should invest in? Well, no worries, we are here to help. These are the best smartwatches available in India</b></p>
<p style="color:tomato;font-size:140%"><b><a href="Motorola  Moto 360 (Gen 2).html" target="_blank">1.Motorola  Moto 360 (Gen 2)
</a> </b></p> 

<tr>
<td><img src="pics/moto1.jpg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
Moto 360�s second avatar is undoubtedly the best looking smartwatch available today. Available with Android Wear and offering a good performance, makes it the best smartwatch to buy at the moment. Pros: Good display, good performance, easy to replace straps Cons: A bit pricey, Battery life though decent has a long way to go
</br></blockquote>








<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Motorola
<br>Product Name:
Motorola  Moto 360 (Gen 2)
<br>Price (MRP):
146246
<br>SOC:
 Qualcomm Snapdragon 400 
 <br>Compatible OS:
 Android 4.3 and above  <br>
 Resolution:
 360 x 330 
 </br></blockquote></td>
</tr></table>
  

<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/Motorola-Moto-360-2nd-Gen/dp/B016CKGQWM?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B016CKGQWM&td_url=http://www.digit.in/top-products/best-smartwatches-in-india.html&tdmid=%2038269220&pagefor=Top10&lang=en&mprice=11668&pid=49476">Motorola  Moto 360 (Gen 2)</a></q></p>

<table>
<tr>


<p style="color:red;font-size:140%"><b><a href="Samsung Gear S2.html" target="_blank">2.Samsung Gear S2</a></b></p>
<td><img src="pics/gear1.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Gear S2 from Samsung is built upon Tizen OS and has a very intuitive rotating dial via which one can interact with the watch. However, the only place the watch lacks is in the apps section. Pros: Rotating bezel is the most intuitive way to navigate around a smartwatch, Very good display, Premium build Cons: Lack of apps, Battery life needs to be longer
</br></blockquote>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Lenovo
<br>Product Name:
Samsung Gear S2
 <br>Price (MRP):
69291
<br>Processor:
 Exynos 3250 
 <br>Compatible OS:
 Android 4.4 and above  <br>
 Resolution:
 360 x 360 
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/Samsung-Gear-Smartwatch-Android-Phones/dp/B015JQ62RY?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B015JQ62RY&td_url=http://www.digit.in/top-products/best-smartwatches-in-india.html&tdmid=%204674821&pagefor=Top10&lang=en&mprice=11668&pid=49476">Samsung Gear S2
</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="Huawei Watch.html" target="_blank">3.Huawei Watch </a> </b></p>
<td><img src="pics/huaw1.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
Huawei�s attempt at making a smartwatch is good but not as good as watches above it. It works well, has reasonably accurate tracking, and is built really well to exude a premium feel. Pros: Very well built, Superior display, Large number of watch faces by default, Decent battery life Cons: Some gestures are not responsive, No noteworthy innovation here
</br></blockquote>

<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Huawei
<br>Product Name:
Huawei Watch  
 <br>Price (MRP):
22999
<br>SOC:
 Qualcomm Snapdragon 400 
 <br>Compatible OS:
 Android 4.3 and above  <br>
 Resolution:
 400 x 400 
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it:-</em><q><a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjS1tzGodjcAhVFqI8KHQUtCT0QFjAAegQICRAB&url=https%3A%2F%2Fconsumer.huawei.com%2Fen%2Fwearables%2F&usg=AOvVaw1mLiCnvpXuV424koeCpJ9Q">Huawei Watch 

</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="Asus ZenWatch 2 W1501Q .html" target="_blank">4.Asus ZenWatch 2 W1501Q </a></b></p>
<td><img src="pics/zen1.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Zenwatch 2 is actually one of the most affordable android wear watches on the market. It also offers a 2 day battery life but it does not as look as premium as any other smartwatch. Although, you need to keep in mind, it is priced quite low as well. Pros: Inexpensive, Premium design, Two-day battery life Cons: Android wear isn't intuitive enough, Display does not respond to gestures well.

</br></blockquote>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Asus
<br>Product Name:
Asus ZenWatch 2 W1501Q 
 <br>Price (MRP):
14999
<br>SOC:
 Qualcomm Snapdragon 400 
 <br>Compatible OS:
 Android 4.3 and above  <br>
 Resolution:
 320 x 320  
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.amazon.in/ASUS-ZenWatch-Android-Wear-Smartwatch/dp/B0163HRGNC">Asus ZenWatch 2 W1501Q 
</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="Pebble Time (Round).html" target="_blank">5.Pebble Time (Round)  </a> </b></p>
<td><img src="pics/pebble1.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Pebble time round is a thin, light and functional smartwatch. It may not offer the rich OS experience of Android Wear or WatchOS but it does provide you with all the essential features you may need from a smartwatch. Also, it does not have a touch-screen. Pros: Slim design, Extremely light, Charges 100% in little over an hour, Decent library of apps and watch faces Cons: Thick bezel, No touch screen, Water resistant only, Low battery life when compared to the Pebble Time
</br></blockquote>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Pebble
<br>Product Name:
Pebble Time (Round) 
 <br>Price (MRP):
13599
<br>SOC:
 Qualcomm Snapdragon 400 
 <br>Compatible OS:
 Android 4.0 and above  <br>
 Resolution:
 360 x 330  
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.amazon.in/Pebble-Technology-Corp-601-00049-Smartwatch/dp/B015N8XR9O">Pebble Time (Round) 
</a></q></p>





<p style="text-align:center;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;"><b><a href="menu.php">BACK</a></b></p>


</body>
</html>

