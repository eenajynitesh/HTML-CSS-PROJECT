<html>
    <head>
        <title>SUBSCRIBE</title>
        <link href="cssmenu1.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div class="row">
            <ul class="navbar">
                <li><a href="index.php">HOME</a></li>
                <li ><a href="menu.php">MENU</a></li>
                <li><a href="gallery.php">GALLERY</a></li>
                <li class="active"><a href="">SUBSCRIBE</a>
                </li>    
            </ul>
<div class="logo">
	<img src="logo2.png">
	</div>
	</div>
<form name="myform" action="conn.php" onsubmit="return ValidateEmail()" method="POST">
  <div class="container">
    
    <input type="text" placeholder="Enter Username" name="uname" required>
<br>     
    <button type="submit">SUBSCRIBE</button>
    
  </div>
</body>
<script>
function ValidateEmail()
{
var x=document.forms["myform"]["uname"].value;

 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(x))
  {
 	return(true);
}
 else{
    alert("You have entered an invalid email address!");
    return (false);
    }
}
</script>
</html>