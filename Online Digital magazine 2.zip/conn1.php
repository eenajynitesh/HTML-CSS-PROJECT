<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";


 mysqli_select_db($conn,"email");

$sql = "INSERT INTO login(username,password) VALUES ('$_POST[uname]','$_POST[psw]')";

if ($conn->query($sql) == TRUE) {
     $message="Sign UP successful";
    echo"<script type='text/javascript'> { alert('$message');} window.location.replace('login.php');</script>";
} else {
     $message="Sign UP Unsuccessful";
    echo"<script type='text/javascript'> { alert('$message');} window.location.replace('signup.php');</script>";
}

mysqli_close($conn);