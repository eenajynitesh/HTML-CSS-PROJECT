<html>
    <head>
        <title>Digital Magazine</title>
        <link href="css.css" rel="stylesheet" type="text/css">

    </head>
    <body>
            <div class="row">
                
                <ul class="navbar">
                    <li class="active"><a href="index.php">HOME</a></li>
                    <li><a href="menu.php">MENU</a></li>
                    <li><a href="">GALLERY</a></li>
                    <li class="drop"><a href="subscribe.php">SUBSCRIBE</a></li>
                    
                    
            
                </ul>
                     <div class="logo">
	<img src="logo2.png">
	</div>
            </div>
            <div class="name"> 
                <h1>Know The Tech <br>
                    <font color= "black"> Stuff!</font> </h1>
                <div class="button">
                    <a href="menu.php" class="btn1"> EXPLORE </a>
                </div>
            </div>
    </body>
</html>
