<html>
<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password,"email");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$id=$_POST["uname"];
$pd=$_POST["psw"];

$sql = "SELECT * FROM `login` WHERE username ='$id'";
$res=$conn->query($sql);
if($res){
  while($row= $res->fetch_assoc()){
  $dpw=$row["password"];
  }
  if(strcmp($dpw,$pd)==0){
	  header("refresh:2 URL=\"index.php\"");
	  
  }else{ $message="Login Unsuccessfull, Check the credentials";
	echo"<script type='text/javascript'> { alert('$message');} window.location.replace('login.php');</script>"; 
	}
}
  
	 
mysqli_close($conn);
?>
</html>