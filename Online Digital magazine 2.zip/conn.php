<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";


 mysqli_select_db($conn,"email");

$sql = "INSERT INTO email(mailid) VALUES ('$_POST[uname]')";

if ($conn->query($sql) == TRUE) {
     $message="You are Subscribed";
    echo"<script type='text/javascript'> { alert('$message');} window.location.replace('subscribe.php');</script>";
} else {
     $message="Subscription Unsuccessful";
    echo"<script type='text/javascript'> { alert('$message');} window.location.replace('subscribe.php');</script>";
}

mysqli_close($conn);