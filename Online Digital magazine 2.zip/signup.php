<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
	background-image: url(w1.jpg);
	background-size: cover;
    background-position: center;
	font-family: Arial, Helvetica, sans-serif;}


input[type=text], input[type=password] {
    width: 30%;
    padding: 8px 10px;
    margin: 8px 480px;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	 text-align: center;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 480px;
    border: none;
    cursor: pointer;
    width: 30%;
	 text-align: center;
	
}

button:hover {
    opacity: 0.8;
}

.signupbtn {
    width: 30%;
    padding: 10px 18px;
	 margin: 8px 480px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 25px 0px 20px 28px;
}

img.avatar {
    width: 30%;
    border-radius:10%;
	
}

.container {
    padding: 8px;
}

span.psw {
    float: right;
    padding-top: 16px;
	  align: center;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .signupbtn {
       width: 30%;
	   align: center;
    }
}
</style>
</head>
<body>



  <div class="imgcontainer">
    <img src="logo1.png" alt="Avatar" class="avatar">
  </div>
<form name="myform" action="conn1.php" method="POST">

  <div class="container">
    
    <input type="text" placeholder="Enter Username" name="uname" required>
<br>
    
    <input type="password" placeholder="Enter Password" name="psw" required>
   <br>     
    <button type="submit">Sign UP</button>
     </div>
    <button type="button" class="signupbtn"><a href="login.php" >BACK</a></button>
    
  </div>
  
  
 </form>
</body>
</html>