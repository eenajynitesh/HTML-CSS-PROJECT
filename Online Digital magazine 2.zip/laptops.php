
<html>
<head>
<style>

a:link {
    color: red;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: black;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: blue;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: yellow;
    background-color: transparent;
    text-decoration: underline;
}

h1 {
    color: blue;
    font-family: verdana;
    font-size: 300%;

}
p  {
    color: red;
    font-family: courier;
    font-size: 160%;margin-right:70px;
}
body {
   background-image: url("pics/background.jpg");
 background-image:no-repeat;
 background-size: 100% 100%;
background-attachment: fixed;
}
p1
{

 color:red;
 font-size:300%;
}

</style>
</head>
<body>
<h1 style="text-align:center;color:White;background-color:rgb(0,128,128);">TOP 5 LAPTOPS</h1>
<table>
<p style="color:black;font-size:100%"><b>Our list of the best laptop in India for 2018 offers a good blend of performance and crucial features, at every price point. The Top 10 laptops in India include options from latest laptops available today, offering budget laptops, mainstream laptops, ultrabooks and business laptops. Take a pick. We're confident you'll find at least one of the latest laptops listed below worth checking out. This is the list of top ten laptops India currently available in the market for all kinds of usage.</b></p>
<p style="color:tomato;font-size:140%"><b><a href="dell xps 15.html" target="_blank">1.Dell XPS 15
</a> </b></p> 

<tr>
<td><img src="pics/xps1.jpg" width=590px height=400px;</td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"></p>



<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The Dell XPS has remained a worthy competitor to Apple�s MacBook and this year as well the newer XPS 15 stands head and shoulders above the competition. The Dell XPS 15 is an amalgamation of everything you would ever need from a mainstream laptop. It has the performance of a gaming laptop, the battery life of an Ultrabook and an industrial design which is tried and tested in the years past.
</br></blockquote>








<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Dell
<br>Product Name:
Dell XPS 15
<br>Price (MRP):
146246
<br>processor model name:
 7th Generation Intel Core i7-7700HQ 
<br>graphics processor:
 NVIDIA GeForce GTX 1050 <br>
 Resolution:
 1920 X 1080 
 </br></blockquote></td>
</tr></table>
  

<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/Dell-XPS9550-0000SLV-15-6-Inch-Traditional-Machined/dp/B015RYT12Q?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B015RYT12Q&td_url=http://www.digit.in/top-products/top-10-laptops.html&tdmid=%20114264405&pagefor=Top10&lang=en&mprice=11668&pid=49476">Dell XPS 15</a></q></p>

<table>
<tr>


<p style="color:red;font-size:140%"><b><a href="Lenovo 530S.html" target="_blank">2.Lenovo IdeaPad 530S </a></b></p>
<td><img src="pics/5301.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
The new generation of Lenovo IdeaPads comes with a more mature design, classy look, and a dependable computing experience. Masthead of the 500-series of IdeaPads, the IdeaPad 530S scores very high on performance, display quality, build, and battery life. It also comes with an Nvidia MX150 GPU for occasional light gaming.
</br></blockquote>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Lenovo
<br>Product Name:
 Lenovo IdeaPad 530S 
 <br>Price (MRP):
69291
<br>processor model name:
 Intel Core i5-8250U 
 <br>graphics processor:
 Nvidia MX 150 
 Resolution:
 1920 X 1080 
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/Lenovo-530S-14IKB-81EU007VIN-I5-8250U-Graphics/dp/B07DXJGQQW?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B07DXJGQQW&td_url=http://www.digit.in/top-products/top-10-laptops.html&tdmid=%20149862360&pagefor=Top10&lang=en&mprice=11668&pid=49476">Lenovo IdeaPad 530S 
</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="HP Spectre x360.html" target="_blank">3.HP Spectre x360 </a> </b></p>
<td><img src="pics/spec1.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
Remember the Spectre 13 from last year. This year we got to see the convertible variant of that laptop. The Spectre x360 in its latest avatar is the best convertible laptop available today. Be it build quality, performance or battery life, the x360 trumps all competition quite easily. It also has one of the best keyboards we have encountered on a convertible laptop, making it a brilliant everyday machine.
</br></blockquote>

<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
HP
<br>Product Name:
HP Spectre x360 
 <br>Price (MRP):
103500
<br>processor model name:
 Intel Core i5 (7th Gen ) 
 <br>graphics processor:
 Intel HD 620 
 Resolution:
 1920 X 1080 
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/HP-x360-Convertible-13-ae502TU-13-3-inch/dp/B079Y8CGQH?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B079Y8CGQH&td_url=http://www.digit.in/top-products/top-10-laptops.html&tdmid=%20139080010&pagefor=Top10&lang=en&mprice=11668&pid=49476">HP Spectre x360 

</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="Asus VivoBook S15 .html" target="_blank">4.Asus VivoBook S15 </a></b></p>
<td><img src="pics/vivo1.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
Besides the Dell XPS 15, the Asus Vivobook S15 is one of the most exciting launches of the year in the mainstream category. The laptop brought a beautiful bezel-less display in a more affordable package along with some really good hardware. The laptop is powered by 8th gen Intel Core processors and offers reliable performance along with a premium looking design. The battery life is a little weak though.

</br></blockquote>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
Asus
<br>Product Name:
 Asus VivoBook S15 
 <br>Price (MRP):
61650
<br>processor model name:
 Intel 8th generation Core i5-8250U 
 <br>graphics processor:
 NVIDIA GeForce MX150 
 Resolution:
 1920 X 1080 
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/Asus-VivoBook-S15-Core-S510UN-BQ217T/dp/B0779QTNVP?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B0779QTNVP&td_url=http://www.digit.in/top-products/top-10-laptops.html&tdmid=%20128637343&pagefor=Top10&lang=en&mprice=11668&pid=49476">Asus VivoBook S15 
</a></q></p>

<table>
<tr>
<p style="color:red;font-size:140%"><b><a href="HP Elitebook x360 1030 G2.html" target="_blank">5.HP Elitebook x360 1030 G2 </a> </b></p>
<td><img src="pics/g21.jpg" width=590px height=400px></td>
<td><p style="color:tomato;font-size:140%; style="font-family:verdana;"><b></b></q></em></p>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>PRODUCT DESCRIPTION</b><br>
On the business side of things, the Elitebook 1030 G2 makes its presence felt as this thin and light dapper looking laptop offers everything a business customer would need. The performance is formidable and keyboard offers one of the best typing experiences you can get today. The laptop also has additional features such as HP sure view which hides the screen contents from peeking eyes.
</br></blockquote>


<blockquote  style="color:black;font-size:120%;border:2px solid black; 
    margin-right: 150px;
    margin-left: 80px;
    padding-top: 20px;
    padding-right: 50px;
    padding-bottom: 20px;
    padding-left: 30px;
"><b>GENERAL INFORMATION</b><br>
Brand:
HP
<br>Product Name:
 HP Elitebook x360 1030 G2 
 <br>Price (MRP):
141690
<br>processor model name:
 Intel Core i7-7600U (7th Gen) 
 <br>graphics processor:
 Intel HD 620 
 Resolution:
 1920 X 1080 
 </br></blockquote></td>
</tr></table>


<p style="color:black;font-size:140%; style="font-family:verdana;"><em>Buy it on Amazon:-</em><q><a href="https://www.digit.in/amazon/merchantdealtrack.php?url=https://www.amazon.in/HP-Y1V98US-ELITEBOOK-M7-6Y75-13-3IN/dp/B01KEGKK3Q?SubscriptionId=AKIAIZBSEE4BJE3N5OCQ&tag=thinkdigit0b-21&linkCode=xm2&camp=2025&creative=165953&creativeASIN=B01KEGKK3Q&td_url=http://www.digit.in/top-products/top-10-laptops.html&tdmid=%20106820374&pagefor=Top10&lang=en&mprice=11668&pid=49476">HP Elitebook x360 1030 G2 
</a></q></p>





<p style="text-align:center;border:2px solid white; 
    margin-right: 150px;
    margin-left: 80px;"><b><a href="menu.php">BACK</a></b></p>


</body>
</html>

